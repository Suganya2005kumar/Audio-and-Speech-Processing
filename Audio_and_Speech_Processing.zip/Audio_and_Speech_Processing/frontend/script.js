
const sttBtn = document.getElementById('sttBtn');
const ttsBtn = document.getElementById('ttsBtn');
const audioFile = document.getElementById('audioFile');
const sttOutput = document.getElementById('sttOutput');
const ttsInput = document.getElementById('ttsInput');
const ttsAudio = document.getElementById('ttsAudio');
const language = document.getElementById('language');

sttBtn.addEventListener('click', async () => {
if (!audioFile.files.length) { alert('Please select an audio file.'); return; }
const formData = new FormData();
formData.append('audio', audioFile.files[0]);
const response = await fetch('/speech-to-text', { method:'POST', body:formData });
if(response.ok){ const data = await response.json(); sttOutput.value = data.text; } 
else alert('Error converting speech.');
});

ttsBtn.addEventListener('click', async () => {
if(!ttsInput.value.trim()){ alert('Please enter text.'); return; }
const response = await fetch('/text-to-speech', {
method:'POST', headers:{'Content-Type':'application/json'},
body:JSON.stringify({text:ttsInput.value, language:language.value})
});
if(response.ok){ const blob = await response.blob(); const url = URL.createObjectURL(blob); ttsAudio.src = url; ttsAudio.play(); }
else alert('Error converting text.');
});
