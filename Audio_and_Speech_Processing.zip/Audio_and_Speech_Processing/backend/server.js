
const express = require('express');
const fileUpload = require('express-fileupload');
const fs = require('fs');
const path = require('path');
const textToSpeech = require('@google-cloud/text-to-speech');
const speech = require('@google-cloud/speech');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));
app.use(fileUpload());

const speechClient = new speech.SpeechClient();
const ttsClient = new textToSpeech.TextToSpeechClient();

app.post('/speech-to-text', async (req, res) => {
    if (!req.files || !req.files.audio) return res.status(400).send('No audio uploaded.');
    const audioFile = req.files.audio;
    const filePath = path.join(__dirname, 'temp.wav');
    await audioFile.mv(filePath);

    const file = fs.readFileSync(filePath);
    const audioBytes = file.toString('base64');

    const request = {
        audio: { content: audioBytes },
        config: { encoding: 'LINEAR16', sampleRateHertz: 44100, languageCode: 'en-US' }
    };

    try {
        const [response] = await speechClient.recognize(request);
        const transcription = response.results.map(r => r.alternatives[0].transcript).join('\n');
        fs.unlinkSync(filePath);
        res.json({ text: transcription });
    } catch (err) {
        console.error(err);
        res.status(500).send('Error during speech-to-text.');
    }
});

app.post('/text-to-speech', async (req, res) => {
    const { text, language = 'en-US' } = req.body;
    if (!text) return res.status(400).send('No text provided.');

    const request = {
        input: { text },
        voice: { languageCode: language, ssmlGender: 'NEUTRAL' },
        audioConfig: { audioEncoding: 'MP3' }
    };

    try {
        const [response] = await ttsClient.synthesizeSpeech(request);
        const outputPath = path.join(__dirname, 'output.mp3');
        fs.writeFileSync(outputPath, response.audioContent, 'binary');
        res.download(outputPath, 'output.mp3', () => fs.unlinkSync(outputPath));
    } catch (err) {
        console.error(err);
        res.status(500).send('Error during text-to-speech.');
    }
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
